const mineflayer = require('mineflayer');
const https = require('https');
const http = require('http');

// ─── Configuration ─────────────────────────────────────────────────────────
// Server + shared behavior settings (same for every bot below)
const server = {
  host: 'play.ohosmp.net',
  port: 19132,
  version: 'auto',                 // 'auto' or a specific version like '1.21.1'
  joinServerCommand: '/server survival', // set to '' if not needed
  reconnectDelay: 5000,             // ms to wait before reconnecting after disconnect
  rateLimitReconnectDelay: 20000,   // ms to wait if server says "too fast" / rate limited
  maxLoginAttempts: 3,
  antiAfk: {
    enabled: true,
    jump: true,
    sneak: false,
    look: true,
    interval: 60000                // ms between anti-AFK actions
  }
};

// 👉 Add as many accounts here as you want — each entry = one bot.
const accounts = [
  { username: 'BOT_USERNAME', authmePassword: 'BOT_PASSWORD' },
  { username: 'BOT_USERNAME2', authmePassword: 'BOT_PASSWORD' },
  { username: 'BOT_USERNAME3', authmePassword: 'BOT_PASSWORD' },
  { username: 'BOT_USERNAME4', authmePassword: 'BOT_PASSWORD' }
];

// Optional Discord webhook logging (leave enabled:false if you don't want this)
const discord = {
  enabled: false,
  webhookUrl: 'YOUR_DISCORD_WEBHOOK_URL_HERE',
  logFilter: {
    connections: false, // join/leave/reconnect/spawn/kick
    errors: true,        // bot errors/crashes
    afk: false,           // anti-AFK loop actions
    warnings: false,
    chat: false,
    auth: true            // successful/failed logins
  }
};

const LOG_COLORS = { info: 0x5865F2, success: 0x57F287, warning: 0xFEE75C, error: 0xED4245, chat: 0xEB459E, afk: 0x9B59B6 };

function sendToDiscord(botId, message, type) {
  if (!discord.enabled || discord.webhookUrl === 'YOUR_DISCORD_WEBHOOK_URL_HERE') return;
  const embed = {
    description: message,
    color: LOG_COLORS[type] || LOG_COLORS.info,
    timestamp: new Date().toISOString(),
    footer: { text: `Bot: ${botId} | ${server.host}` }
  };
  const payload = JSON.stringify({ embeds: [embed] });
  try {
    const url = new URL(discord.webhookUrl);
    const lib = url.protocol === 'https:' ? https : http;
    const req = lib.request({
      hostname: url.hostname,
      path: url.pathname + url.search,
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) }
    });
    req.on('error', () => {});
    req.write(payload);
    req.end();
  } catch (e) {}
}

function log(botId, message, type = 'info') {
  const icons = { info: 'ℹ️', success: '✅', warning: '⚠️', error: '❌', chat: '💬', afk: '🔄' };
  console.log(`[${new Date().toLocaleTimeString()}] [${botId}] ${icons[type] || 'ℹ️'} ${message}`);

  if (!discord.enabled) return;
  const f = discord.logFilter;
  const m = message.toLowerCase();

  if (!f.connections && (m.includes('joined') || m.includes('disconnected') || m.includes('reconnecting') ||
      m.includes('creating bot') || m.includes('kicked') || m.includes('spawned'))) return;
  if (type === 'error' && !f.errors) return;
  if (type === 'afk' && !f.afk) return;
  if (type === 'warning' && !f.warnings) return;
  if (type === 'chat' && !f.chat) return;
  if (!f.auth && (m.includes('login') || m.includes('authme'))) return;

  sendToDiscord(botId, message, type);
}

function createBot(account) {
  const id = account.username;
  const state = {
    authmeCompleted: false,
    loginAttempts: 0,
    serverJoined: false,
    timers: []
  };

  const safeTimeout = (fn, delay) => {
    const t = setTimeout(() => { state.timers = state.timers.filter(x => x !== t); fn(); }, delay);
    state.timers.push(t);
    return t;
  };
  const clearAllTimers = () => { state.timers.forEach(t => { clearTimeout(t); clearInterval(t); }); state.timers = []; };
  const botChat = (message) => {
    if (bot && typeof bot.chat === 'function') {
      try { bot.chat(message); } catch (e) { log(id, `Failed to send chat: ${e.message}`, 'error'); }
    }
  };

  const botOptions = {
    host: server.host,
    port: server.port,
    username: account.username,
    auth: 'offline',
    physicsEnabled: false, // no movement/pathfinder needed — just stays connected
    hideErrors: false
  };
  if (server.version && server.version !== 'auto') botOptions.version = server.version;

  log(id, '🤖 Creating bot...', 'info');
  const bot = mineflayer.createBot(botOptions);

  function attemptAuthMeLogin() {
    if (state.authmeCompleted) return;
    log(id, '🔐 Attempting AuthMe login...', 'warning');

    safeTimeout(() => {
      botChat(`/login ${account.authmePassword}`);
      log(id, '🔑 Sent /login', 'info');
      state.loginAttempts++;
    }, 7000);

    // If no AuthMe response after 15s, assume it's not required / already done
    safeTimeout(() => {
      if (!state.authmeCompleted) {
        log(id, '⚠️ No AuthMe response, assuming authenticated', 'warning');
        state.authmeCompleted = true;
        if (server.joinServerCommand) {
          safeTimeout(joinSpecificServer, 2000);
        } else {
          safeTimeout(startBotActivities, 1000);
        }
      }
    }, 15000);
  }

  function joinSpecificServer() {
    log(id, `🌍 Joining: ${server.joinServerCommand}`, 'info');
    botChat(server.joinServerCommand);
    state.serverJoined = true;
    safeTimeout(() => {
      if (state.authmeCompleted && !state.serverJoined) startBotActivities();
    }, 10000);
    safeTimeout(startBotActivities, 2000);
  }

  function startBotActivities() {
    if (!server.antiAfk.enabled) return;
    log(id, '🎯 Starting anti-AFK loop', 'info');
    const afkTimer = setInterval(() => {
      if (!bot || !bot._client || bot._client.state !== 'play') return;
      try {
        if (server.antiAfk.jump) {
          bot.setControlState('jump', true);
          safeTimeout(() => { if (bot && bot.setControlState) bot.setControlState('jump', false); }, 100);
        }
        if (server.antiAfk.sneak) {
          bot.setControlState('sneak', true);
          safeTimeout(() => { if (bot && bot.setControlState) bot.setControlState('sneak', false); }, 200);
        }
        if (server.antiAfk.look) {
          const yaw = (Math.random() - 0.5) * Math.PI;
          bot.look(yaw, 0, false);
        }
        log(id, 'Anti-AFK action performed', 'afk');
      } catch (error) {
        log(id, `Anti-AFK error: ${error.message}`, 'error');
      }
    }, server.antiAfk.interval);
    state.timers.push(afkTimer);
  }

  bot.once('login', () => {
    log(id, `🔓 Connected as ${bot.username}, starting AuthMe...`, 'success');
    state.authmeCompleted = false;
    state.loginAttempts = 0;
    state.serverJoined = false;
    safeTimeout(attemptAuthMeLogin, 500);
  });

  bot.once('spawn', () => {
    log(id, `✅ Spawned as ${bot.username}`, 'success');
    // If we spawned without ever seeing an AuthMe prompt, server likely
    // doesn't require it (or remembered the session) — treat as done.
    if (!state.authmeCompleted) {
      state.authmeCompleted = true;
      if (server.joinServerCommand) {
        safeTimeout(joinSpecificServer, 2000);
      } else {
        safeTimeout(startBotActivities, 1000);
      }
    }
  });

  // Print server chat/messages with the SAME colors as in-game, using ANSI codes
  bot.on('message', (jsonMsg) => {
    try {
      const ansiText = jsonMsg.toAnsi();
      if (!ansiText || ansiText.includes(bot.username)) return; // skip our own messages
      console.log(`[${new Date().toLocaleTimeString()}] [${id}] \x1b[0m${ansiText}\x1b[0m`);
    } catch (e) {}
  });

  bot.on('messagestr', (message) => {
    if (message.startsWith(bot.username) || message.includes(`<${bot.username}>`)) return;
    const m = message.toLowerCase();

    if (state.serverJoined && m.includes('survival') &&
        (m.includes('joined') || m.includes('connected') || m.includes('welcome'))) {
      log(id, '🌍 Joined survival server', 'success');
      safeTimeout(startBotActivities, 2000);
      return;
    }

    if ((m.includes('login') || m.includes('log in')) &&
        (m.includes('password') || m.includes('/login') || m.includes('command'))) {
      log(id, '🔑 Login required detected', 'warning');
      safeTimeout(() => { botChat(`/login ${account.authmePassword}`); state.loginAttempts++; }, 7000);
      return;
    }

    if ((m.includes('successfully') || m.includes('welcome') || m.includes('logged')) &&
        (m.includes('logged') || m.includes('authenticated'))) {
      log(id, '✅ AuthMe login confirmed', 'success');
      state.authmeCompleted = true;
      if (server.joinServerCommand) {
        safeTimeout(joinSpecificServer, 2000);
      } else {
        safeTimeout(startBotActivities, 1000);
      }
      return;
    }

    if (m.includes('wrong password') || m.includes('incorrect password') || m.includes('invalid password')) {
      log(id, '❌ Wrong AuthMe password', 'error');
      if (state.loginAttempts < server.maxLoginAttempts) {
        safeTimeout(() => { botChat(`/login ${account.authmePassword}`); state.loginAttempts++; }, 3000);
      } else {
        log(id, '🚫 Max login attempts reached', 'error');
      }
      return;
    }

    if (m.includes('timeout') || (m.includes('time') && m.includes('up')) || m.includes('too slow')) {
      log(id, '⏰ AuthMe timeout, retrying', 'warning');
      if (!state.authmeCompleted) safeTimeout(attemptAuthMeLogin, 2000);
      return;
    }

    if (m.includes('not authenticated') || m.includes('please login')) {
      log(id, '⚠️ Login required message', 'warning');
      if (!state.authmeCompleted) safeTimeout(attemptAuthMeLogin, 1000);
    }
  });

  bot.on('kicked', (reason) => {
    let kickReason = 'Unknown reason';
    if (reason) {
      kickReason = typeof reason === 'string' ? reason
        : (reason.toString && reason.toString() !== '[object Object]') ? reason.toString()
        : JSON.stringify(reason);
    }
    log(id, `⚠️ Kicked: ${kickReason}`, 'error');
    clearAllTimers();

    let delay = server.reconnectDelay;
    if (kickReason.toLowerCase().includes('too fast') || kickReason.toLowerCase().includes('rate limit') || kickReason.toLowerCase().includes('limit')) {
      delay = server.rateLimitReconnectDelay;
      log(id, `⏳ Rate limited, waiting ${delay / 1000}s...`, 'warning');
    }
    setTimeout(() => createBot(account), delay);
  });

  bot.on('error', (err) => {
    log(id, `❌ Error: ${err.message}`, 'error');
  });

  bot.on('end', () => {
    log(id, '🔌 Disconnected. Reconnecting...', 'warning');
    clearAllTimers();
    setTimeout(() => createBot(account), server.reconnectDelay);
  });

  return bot;
}

log('MAIN', `🤖 Starting ${accounts.length} bot(s)...`, 'info');
// Stagger the joins so they don't all hit the server in the exact same tick
accounts.forEach((account, i) => {
  setTimeout(() => createBot(account), i * 5000);
});

process.on('SIGINT', () => process.exit(0));
process.on('SIGTERM', () => process.exit(0));
process.on('uncaughtException', (err) => {
  log('MAIN', `💥 Uncaught exception: ${err.message}`, 'error');
});
